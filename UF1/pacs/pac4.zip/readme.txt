-----------------------------------------------------------------------------
		ENUNCIAT
-----------------------------------------------------------------------------
Es demana muntar en html+less les p�gines web mostrades a les captures.
S�n b�sicament 3:
	* Home page
	* Cercador de productes
	* Cistell de la compra

�s demana que totes tinguin una versi� desktop, tablet i m�bil. Per facilitar-vos la feina, ja teniu el disseny de la versi� m�bil de la home fet. Caldr� que dissenyeu vosaltres mateixos la resta.

Fixeu-vos que la home page inclou tamb� un disseny dels men�s dropdown de la barra superior de navegaci� i del cistell de la compra. De la mateixa forma, fixeu-vos que hi ha efectes hover i carrousels que cal implementar.

La pr�ctica es far� usant Bootstrap, i ha de ser funcional amb IE8 o superiors, i �ltimes versions de Chrome i Firefox.

Per evitar repetir codi en zones de cap�alera i peu ( o fins i tot en p�gines de productes ), podeu usar php per crear plantilles.

Es valorar�:
 - L'acabat final de la web. Es requereix un acabat professional.
 - Funcionament responsiu coherent i adequat.
 - Personalitzacions de l'estil i del contingut
 - Cross-browser full support.
 - HTML sem�ntic, ben organitzat
 - Utilitzaci� del CSS i del Less curosa.

-----------------------------------------------------------------------------
		APP�NDIX
-----------------------------------------------------------------------------
Fonts utilitzades:
	Rock Salt ( no �s exacta, per� pel logo est� b� ! )
    Open Sans (Text)
    Josefin Sans (Text)
    Poppins (Text)
    Icon font Awesome

Algunes webs d'on manllevar fotos:
	https://www.pexels.com/search/fashion/
	http://www.istockphoto.com/es/fotos/fashion
	http://stockphotos.io/
	http://www.stocka.co/
	http://www.splitshire.com/
	 Photype.co
	http://kaboompics.com/
	http://fancycrave.com/
	http://instastock.co/
	http://www.gratisography.com/
	http://www.lifeofpix.com/
	http://startupstockphotos.com/
	http://picjumbo.com/